a=single(9.4);b=single(9);c=single(0.4);
d=a-b-c;
fprintf('%.12f',d);